import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) throws RoomNotFoundException {
        Hotel hotel = new Hotel();


        List<Occupants> singleRoomOccupant=new ArrayList<>();
        List<Occupants>doubleRoomOccupant=new ArrayList<>();
        List<Occupants>suitRoomOccupant=new ArrayList<>();
        Occupants occupants=new Occupants("Purushotham","bglr");
        Occupants occupants1=new Occupants("gangadhar","pune");
        Occupants occupants2 =new Occupants("madhu","Chennai");
        Occupants occupants3 =new Occupants("madhuJ","Chennai");
        singleRoomOccupant.add(occupants1);

        doubleRoomOccupant.add(occupants2);
        doubleRoomOccupant.add(occupants);

         suitRoomOccupant.add(occupants);
        suitRoomOccupant.add(occupants1);
        suitRoomOccupant.add(occupants2);
        suitRoomOccupant.add(occupants3);

        Room room=new Room("100",RoomType.SINGLE,true);
        Room room1=new Room("101",RoomType.DOUBLE,true);
        Room room2=new Room("102",RoomType.SUITE,true);


        hotel.addRoom(room);
        hotel.addRoom(room1);
        hotel.addRoom(room2);


        hotel.reserveRooms("103",doubleRoomOccupant);
        //hotel.reserveRooms("101",doubleRoomOccupant);
        //hotel.reserveRooms("100",singleRoomOccupant);
        List<Room> availableRooms = hotel.getAvailableRooms();
        List<Room> occupiedRooms = hotel.getOccupiedRooms();
        //hotel.reserveRooms("100",singleRoomOccupant);

        System.out.println(availableRooms);
        System.out.println(occupiedRooms);


    }



}