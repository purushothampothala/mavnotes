public class BankUser {
    private String name;
    private String accountNumber;
    private String location;
    private double balance;

    public BankUser() {

    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public  String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public BankUser(String name, String accountNumber, String location,double balance) {
        this.name = name;
        this.accountNumber = accountNumber;
        this.location = location;
        this.balance=balance;
    }

    @Override
    public String toString() {
        return "BankUser{" +
                "name='" + name + '\'' +
                ", accountNumber='" + accountNumber + '\'' +
                ", location='" + location + '\'' +
                ", balance='" + balance + '\'' +
                '}';
    }


    public double credit(double amount) {
    balance=balance+amount;
    return amount;
    }
    public double debit(double amount) throws InsufficientFundException {
            balance=balance-amount;
        return amount;
    }









    public  double transferFund(String sourceaccount, String destinationAccount, double amount) throws InsufficientFundException {
            System.out.println("trans");
            if (getAccountNumber().equals(sourceaccount)) {
                setBalance(debit(amount));
            }
            if (getAccountNumber().equals(destinationAccount)) {
                setBalance(credit(amount));
            }




        return amount;
    }
}

