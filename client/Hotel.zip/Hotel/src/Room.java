import java.util.List;

public class Room {
    private String roomNumber;
    private RoomType roomType;
    private boolean isAvailable;
    private List<Occupants> occupants;

    public String getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }

    public RoomType getRoomType() {
        return roomType;
    }

    public void setRoomType(RoomType roomType) {
        this.roomType = roomType;
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    public void setAvailable(boolean available) {
        isAvailable = available;
    }

    public List<Occupants> getOccupants() {
        return occupants;
    }

    public void setOccupants(List<Occupants> occupants) {

        this.occupants = occupants;

    }

    public Room(String roomNumber, RoomType roomType, boolean isAvailable, List<Occupants> occupants) {
        this.roomNumber = roomNumber;
        this.roomType = roomType;
        this.isAvailable = isAvailable;
        this.occupants = occupants;
    }

    public Room(String roomNumber, RoomType roomType,boolean isAvailable) {
        this.roomNumber = roomNumber;
        this.roomType = roomType;
        this.isAvailable=isAvailable;
    }

    @Override
    public String toString() {
        return "Room{" +
                "roomNumber='" + roomNumber + '\'' +
                ", roomType=" + roomType +
                ", isAvailable=" + isAvailable +
                ", occupants=" + occupants +
                '}';
    }
}