import java.util.ArrayList;
import java.util.List;

public class Hotel {
    private List<Room> rooms;

    public Hotel() {
        this.rooms = new ArrayList<>();
    }


    public void addRoom(Room room) {
        this.rooms.add(room);
    }

    public void reserveRooms(String currentRoom, List<Occupants> numberOfGuests) throws RoomNotFoundException {

        Room room = findRoomByNumber(currentRoom);
        //for (Room rooms : rooms) {
        if (room.isAvailable() == false) {
            throw new RoomNotFoundException("Room is already occupied");
        }
        if (room==null) {
            throw new RoomNotFoundException("Room Not fouond");
        }

        if (room.isAvailable() && room.getRoomType().RoomType() > numberOfGuests.size()) {
            throw new RoomNotFoundException("Room cannot accommodate the given number of guests ");
        }

        room.setAvailable(false);
    }


    private Room findRoomByNumber(String roomNumber) throws RoomNotFoundException {
        for (Room room : rooms) {
            if (room.getRoomNumber().equals(roomNumber)) {
               // if (room.getRoomNumber().equals(roomNumber)) {
                    //room.setAvailable(false);
                return room;
                }
            }
        return null;
    }



    public List<Room>getAvailableRooms(){
        List<Room>availableRooms=new ArrayList<>();
        for(Room room:rooms){
            if(room.isAvailable()==true){
                availableRooms.add(room);
            }
        }
        return availableRooms;
    }
    public List<Room> getOccupiedRooms() {
        List<Room> occupiedRooms = new ArrayList<>();
        for (Room room : rooms) {
            if (room.isAvailable()==false) {
                occupiedRooms.add(room);
            }
        }
        return occupiedRooms;
    }

}
