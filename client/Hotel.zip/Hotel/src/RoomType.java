 enum RoomType {
     SINGLE(1),
     DOUBLE(2),
     SUITE(4);

     // declaring private variable for getting values
     private int maximumCapacity;

     // getter method
     public int RoomType()
     {
         return this.maximumCapacity;
     }

     // enum constructor - cannot be public or protected
     private RoomType(int maximumCapacity)
     {
         this.maximumCapacity = maximumCapacity;
     }
 }


