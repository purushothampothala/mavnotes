package assignment_one;

public enum RoomType {
    SINGLE(4),
    DOUBLE(8),
    SUITE(12);
    private int guests;

    RoomType(int guests) {
        this.guests = guests;
    }

    public int getGuests() {
        return guests;
    }
}
