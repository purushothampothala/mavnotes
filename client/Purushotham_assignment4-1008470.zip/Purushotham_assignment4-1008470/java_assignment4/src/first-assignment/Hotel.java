package assignment_one;

import assignment_one.exceptions.InsufficientCapacityException;
import assignment_one.exceptions.RoomNotFoundException;
import assignment_one.exceptions.RoomUnavailableException;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Hotel {
    private List<Room> rooms;

    public Hotel() {
        rooms = new ArrayList<>();
    }

    public void addRoom(Room room) {
        rooms.add(room);
    }

    public void reserveRoom(String roomNumber, List<Occupants> numberOfGuests) throws RoomNotFoundException, RoomUnavailableException, InsufficientCapacityException {
        Room currentRoom = findRoom(roomNumber);
        currentRoom.setOccupants(currentRoom, numberOfGuests);
    }


    public List<Room> getAvailableRooms() {
        return rooms.stream()
                .filter(room -> room.isAvailable())
                .collect(Collectors.toList());
    }

    public List<Room> getOccupiedRooms() {
        return rooms.stream()
                .filter(room -> !room.isAvailable())
                .collect(Collectors.toList());
    }

    private Room findRoom(String roomNumber) throws RoomNotFoundException {
        return rooms
                .stream()
                .filter(room -> room.getRoomNumber().equals(roomNumber))
                .findFirst()
                .orElseThrow(() -> new RoomNotFoundException("Room not found"));
    }
}

