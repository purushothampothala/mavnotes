package assignment_one;

import assignment_one.exceptions.InsufficientCapacityException;
import assignment_one.exceptions.RoomUnavailableException;

import java.util.ArrayList;
import java.util.List;

public class Room {
    private String roomNumber;
    private RoomType roomType;
    private boolean isAvailable;
    private List<Occupants> occupants;

    public Room(String roomNumber,
                RoomType roomType) {
        this.roomNumber = roomNumber;
        this.roomType = roomType;
        this.isAvailable = true;
        occupants = new ArrayList<>();
    }

    public String getRoomNumber() {
        return roomNumber;
    }

    public RoomType getRoomType() {
        return roomType;
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    public void setAvailable(boolean available) {
        isAvailable = available;
    }

    public List<Occupants> getOccupants() {
        return occupants;
    }

    public void setOccupants(Room currentRoom, List<Occupants> numberOfGuests) throws RoomUnavailableException, InsufficientCapacityException {
        if (!currentRoom.isAvailable())
            throw new RoomUnavailableException("room is already reserved");
        else if (currentRoom.isAvailable()) {
            if (currentRoom.getRoomType().getGuests() >= numberOfGuests.size()) {
                currentRoom.setAvailable(false);
                this.occupants = numberOfGuests;
            } else throw new InsufficientCapacityException("room capacity exceeded");
        }
    }

    @Override
    public String toString() {
        return "Room{" +
                "roomNumber='" + roomNumber + '\'' +
                ", roomType=" + roomType +
                ", isAvailable=" + isAvailable +
                '}';
    }
}
