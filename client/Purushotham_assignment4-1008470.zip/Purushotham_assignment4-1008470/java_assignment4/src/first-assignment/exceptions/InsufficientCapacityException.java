package assignment_one.exceptions;

public class InsufficientCapacityException extends Exception {
    private String message;

    public InsufficientCapacityException(String message) {
        super(message);
        this.message = message;
    }
    public String getMessage(){
        return message;
    }
}
