package assignment_one.exceptions;

public class RoomNotFoundException extends Exception {
private String message;
    public RoomNotFoundException(String message) {
        super(message);
        this.message=message;
    }
    public String getMessage(){
        return message;
    }
}
