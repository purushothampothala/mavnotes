package assignment_one.exceptions;

public class RoomUnavailableException extends Exception {
    private String message;

    public RoomUnavailableException(String message) {
        super(message);
        this.message = message;
    }

    public String getMessage() {
        return message;
    }
}
