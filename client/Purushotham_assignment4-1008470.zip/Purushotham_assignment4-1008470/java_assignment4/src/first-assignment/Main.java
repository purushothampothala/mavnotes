package assignment_one;

import assignment_one.exceptions.InsufficientCapacityException;
import assignment_one.exceptions.RoomNotFoundException;
import assignment_one.exceptions.RoomUnavailableException;

import java.util.Arrays;
import java.util.List;

public class Main {
    public static void main(String[] args) throws RoomNotFoundException, RoomUnavailableException, InsufficientCapacityException {
        Hotel hotel = new Hotel();
        List<Occupants> occupants1 = Arrays.asList(
                new Occupants("gangadhar", "madanapalle", "male"),
                new Occupants("purushotham", "kadapa", "male"),
                new Occupants("nandini", "hyderabad", "female"));

        List<Occupants> occupants2 = Arrays.asList(
                new Occupants("raj", "kolar", "male"),
                new Occupants("somu", "rayachoti", "male"),
                new Occupants("divya", "bangalore", "female"),
                new Occupants("roshini", "chennai", "female"));

        Room room1 = new Room("001", RoomType.SINGLE);
        Room room2 = new Room("002", RoomType.DOUBLE);
        Room room3 = new Room("003", RoomType.SUITE);

        hotel.addRoom(room1);
        hotel.addRoom(room2);
        hotel.addRoom(room3);

        hotel.reserveRoom("001", occupants1);
        hotel.reserveRoom("002", occupants2);

        hotel.getAvailableRooms().stream().forEach(System.out::println);
        System.out.println();
        hotel.getOccupiedRooms().stream().forEach(System.out::println);

    }
}