package assignment_one;

public class Occupants {
    private String name;
    private String location;
    private String gender;

    public Occupants(String name, String gender, String location) {
        this.location = location;
        this.name = name;
        this.gender = gender;
    }

    public String getLocation() {
        return location;
    }

    public void setId(String location) {
        this.location = location;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    @Override
    public String toString() {
        return "Occupants{" +
                "name='" + name + '\'' +
                ", location='" + location + '\'' +
                ", gender='" + gender + '\'' +
                '}';
    }
}
