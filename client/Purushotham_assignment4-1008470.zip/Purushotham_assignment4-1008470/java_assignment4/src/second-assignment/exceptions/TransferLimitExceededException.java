package assignment_three.exceptions;

public class TransferLimitExceededException extends Exception {
    private String message;

    public TransferLimitExceededException(String message) {
        super(message);
        this.message = message;
    }

    public String getMessage() {
        return message;
    }
}
