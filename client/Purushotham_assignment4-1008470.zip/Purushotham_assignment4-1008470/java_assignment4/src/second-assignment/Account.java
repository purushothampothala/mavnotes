package assignment_three;

import assignment_three.exceptions.AccountNotFoundException;
import assignment_three.exceptions.InsufficientFundsException;
import assignment_three.exceptions.TransferLimitExceededException;

import java.util.ArrayList;
import java.util.List;

public class Account {
    private static final int limit = 50000;
    private String account;
    private int balance;

    private static List<Account> accountList;

    public Account(String account, int balance) {
        this.account = account;
        this.balance = balance;
        accountList = new ArrayList<>();
    }

    public int getLimit() {
        return limit;
    }

    public String getAccount() {
        return account;
    }

    public int getBalance() {
        return balance;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public void setBalance(int balance) {
        this.balance = balance;
    }

    private static Account fetchAccount(String source) throws AccountNotFoundException {
        Account account = accountList.stream()
                .filter(acc -> acc.getAccount().equals(source))
                .findFirst()
                .orElseThrow(() -> new AccountNotFoundException("account not found"));
        return account;
    }

    public static List<Account> getAccountList() {
        return accountList;
    }

    public static void addAccount(Account account) {
        accountList.add(account);
    }

    public static void transferFunds(String source, String destination, int balance) {
        try {
            Account srcAcc = fetchAccount(source);
            Account destAcc = fetchAccount(destination);

            if (balance > srcAcc.getBalance())
                throw new InsufficientFundsException("insufficient balance for transfer");
            if (balance > destAcc.getLimit())
                throw new TransferLimitExceededException("transfer limit exceeded");
            else {
                destAcc.setBalance(destAcc.getBalance() + balance);
                srcAcc.setBalance(srcAcc.getBalance() - balance);
            }
        } catch (InsufficientFundsException | TransferLimitExceededException | AccountNotFoundException e) {
            throw new RuntimeException(e);
        }
    }
}
