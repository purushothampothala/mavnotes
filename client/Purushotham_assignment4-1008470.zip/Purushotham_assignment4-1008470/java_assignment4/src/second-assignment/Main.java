package assignment_three;

import assignment_three.exceptions.AccountNotFoundException;
import assignment_three.exceptions.InsufficientFundsException;
import assignment_three.exceptions.TransferLimitExceededException;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        Account acc1 = new Account("001", 75000);
        Account acc2 = new Account("002", 24000);
        Account acc3 = new Account("003", 14500);

        Account.addAccount(acc1);
        Account.addAccount(acc2);
        Account.addAccount(acc3);

        Account.transferFunds("003", "002", 14000);

        System.out.println("source account balance      : " + acc3.getBalance());
        System.out.println("destination account balance : " + acc2.getBalance());
    }
}
