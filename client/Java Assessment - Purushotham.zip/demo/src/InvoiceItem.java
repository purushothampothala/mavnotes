public class InvoiceItem {

    public static void main(String[]args) {
        InvoiceItem invoiceItem = new InvoiceItem("1","item",2,10.00);
        InvoiceItem invoiceItem1 = new InvoiceItem("2","item2",3,11.00);
       double total= invoiceItem.getTotal(invoiceItem.getUnitPrice(),invoiceItem.getQty());
      double total1=  invoiceItem1.getTotal(invoiceItem1.getUnitPrice(),invoiceItem1.getQty());
        System.out.println(invoiceItem+ "  Total price"+total);
        System.out.println(invoiceItem1+ "  Total Price"+total1);

    }

    private String id;
    private String desc;
    private int qty;
    private double unitPrice;
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public int getQty() {
        return qty;
    }

    public void setQty(int qty) {
        this.qty = qty;
    }

    public double getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(double unitPrice) {
        this.unitPrice = unitPrice;
    }

    @Override
    public String toString() {
        return "InvoiceItem{" +
                "id='" + id + '\'' +
                ", desc='" + desc + '\'' +
                ", qty=" + qty +
                ", unitPrice=" + unitPrice +
                '}';
    }

    public InvoiceItem(String id, String desc, int qty, double unitPrice) {
        this.id = id;
        this.desc = desc;
        this.qty = qty;
        this.unitPrice = unitPrice;
    }

    public double getTotal(double unitPrice,int qty){

        return unitPrice*qty;
    }
}
