public class Account {
public static void main(String[]args){
    Account acc=new Account("1","purushotham",20000);
    Account acc1=new Account("2","gangadhar",10000);
    System.out.println(acc);
    System.out.println(acc1);
    acc.credit(1000);
    acc1.credit(2000);
    System.out.println("After crediting the amount"+acc);
    System.out.println("After crediting the amount"+acc1);

    acc.debit(3000);
    acc1.debit(4000);
    System.out.println("After debiting the amount"+acc);
    System.out.println("After debiting the amount"+acc1);

    acc1.transferTo(acc,1000);
    System.out.println(acc1);
}

    private String id;
    private String name;
    private int balance;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getBalance() {
        return balance;
    }

    public void setBalance(int balance) {
        this.balance = balance;
    }

    @Override
    public String toString() {
        return "Account{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", balance=" + balance +
                '}';
    }

    public Account(String id, String name, int balance) {
        this.id = id;
        this.name = name;
        this.balance = balance;
    }
public int credit(int amount){
        balance=balance+amount;
        return balance;
}
public int debit(int amount){
        balance=balance-amount;
        return balance;
}
public int  transferTo(Account account,int amount){
        if(amount<=balance) {
            balance = balance - amount;
        }
            else{
                System.out.println("Amount exceeds balance");
            }
        return balance;
}

}
