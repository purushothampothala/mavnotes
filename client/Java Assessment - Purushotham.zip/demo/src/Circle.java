public class Circle {
    public static void main(String[] args) {

      Circle circle = new Circle();
      System.out.println("Area "+circle.getArea());
      System.out.println("Radius "+circle.getRadius());
    }
        private double radius;
        private String color;

        // Default constructor
        public Circle() {
            this.radius = 1.0;
            this.color = "red";
        }

        // Constructor with radius argument
        public Circle(double radius) {
            this.radius = radius;
            this.color = "red";
        }

        // Getter for radius
        public double getRadius() {
            return radius;
        }

        // Getter for area
        public double getArea() {
            return Math.PI * radius * radius;
        }

    }

