
public class Permutation {

    public static void printAllPermutations(
            int n, int[] elements, char delimiter) {
        if (n == 1) {
            printArray(elements, delimiter);
        } else {
            for (int i = 0; i < n - 1; i++) {
                printAllPermutations(n - 1, elements, delimiter);
                if (n % 2 == 0) {
                    swap(elements, i, n - 1);
                } else {
                    swap(elements, 0, n - 1);
                }
            }
            printAllPermutations(n - 1, elements, delimiter);
        }
    }

    private static void printArray(int[] input, char delimiter) {
        int i = 0;
        for (; i < input.length; i++) {
            System.out.print(input[i]);
        }
        System.out.print(delimiter);
    }

    private static void swap(int[] input, int a, int b) {
        int tmp = input[a];
        input[a] = input[b];
        input[b] = tmp;
    }

    public static void main(String[] args) {
        int[] input = new int[]{1, 2, 3};
        printAllPermutations(input.length, input, ',');
    }
}