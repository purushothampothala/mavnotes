import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class Factory {
        private List<Employee> employees;

        public Factory() {
            employees = new ArrayList<>();
        }

        public void addEmployee(Employee employee) {
            employees.add(employee);
        }
      public void displayEmployeesSortedByNameAndAge() {
     List<Employee> sortedList=
       employees.stream().sorted(Comparator.comparingInt(Employee::getAge)).collect(Collectors.toList());
       System.out.println("sorted by age  === "+sortedList);
        }

    public void displayEmployeesSortedByName() {
        List<Employee> sortedList=
                employees.stream().sorted(Comparator.comparing(Employee::getName)).collect(Collectors.toList());
        System.out.println("sorted by name  === "+sortedList);
    }}