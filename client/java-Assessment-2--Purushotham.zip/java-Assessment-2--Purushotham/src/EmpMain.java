import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class EmpMain{

    public static void main(String[] args) {
        // Create Employee objects
        Employee employee1 = new Employee("purushotham", 40, "Bglr", "java");
        Employee employee2 = new Employee(" gangadhar", 30, "pune", "java");
        Employee employee3 = new Employee("madhu", 28, "chennai", "java");

        // Create Factory object
        Factory factory = new Factory();

        // Add employees to the factory
        factory.addEmployee(employee1);
        factory.addEmployee(employee2);
        factory.addEmployee(employee3);

        // Display employees sorted by name and age
        factory.displayEmployeesSortedByNameAndAge();
        factory.displayEmployeesSortedByName();

    }


}